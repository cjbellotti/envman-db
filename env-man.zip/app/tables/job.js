var manageJob = require('../lib/manage-job')(__dirname + '/data/jobs.json');
module.exports = manageJob;