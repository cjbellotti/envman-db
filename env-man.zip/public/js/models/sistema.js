EnvMan.Models.Sistema = Backbone.Model.extend({
	idAttribute : "ID"
});