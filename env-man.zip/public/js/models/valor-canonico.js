EnvMan.Models.ValorCanonico = Backbone.Model.extend({
	idAttribute : "ID"
});