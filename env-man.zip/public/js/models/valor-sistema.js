EnvMan.Models.ValorSistema = Backbone.Model.extend({
	idAttribute : "ID"
});