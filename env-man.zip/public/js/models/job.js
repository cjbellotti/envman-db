EnvMan.Models.Job = Backbone.Model.extend({
	url : '/job'
});