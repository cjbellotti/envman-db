EnvMan.Models.Entidad = Backbone.Model.extend({
	idAttribute : "ID"
});