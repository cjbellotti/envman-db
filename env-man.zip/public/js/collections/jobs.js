EnvMan.Collections.Jobs = Backbone.Collection.extend({

	model : EnvMan.Models.Job,
	url : '/job'

});